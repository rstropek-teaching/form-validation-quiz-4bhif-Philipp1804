module.exports = {
    "files": "dist/index.*",
    "server": "dist",
    "reloadDebounce": 2000
};